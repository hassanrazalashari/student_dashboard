/* script.js */
const themeToggle = document.getElementById('themeToggle');
const body = document.body;
const profilePic = document.getElementById('profilePic');
const uploadPhoto = document.getElementById('uploadPhoto');
const reminderInput = document.getElementById('reminderInput');
const addReminder = document.getElementById('addReminder');
const reminderList = document.getElementById('reminderList');

// Theme Toggle
themeToggle.addEventListener('change', () => {
    body.classList.toggle('dark-mode');
});

// Profile Picture Upload
uploadPhoto.addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            profilePic.src = e.target.result;
        }
        reader.readAsDataURL(file);
    }
});

// Add Study Reminder
addReminder.addEventListener('click', () => {
    if (reminderInput.value.trim() !== '') {
        const li = document.createElement('li');
        li.textContent = reminderInput.value;
        reminderList.appendChild(li);
        reminderInput.value = '';
    }
});

// Tab Navigation
function openSection(event, sectionId) {
    let sections = document.getElementsByClassName('section');
    let tabs = document.getElementsByClassName('tablink');

    for (let i = 0; i < sections.length; i++) {
        sections[i].classList.remove('active');
        tabs[i].classList.remove('active');
    }

    document.getElementById(sectionId).classList.add('active');
    event.currentTarget.classList.add('active');
}